# app/main.py

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
from app.routes import router as auth_router

app = FastAPI()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Подключаем статику
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "frontend", "static")), name="static")

# Шаблоны
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# Рендерим страницу логина
@app.get("/", response_class=HTMLResponse)
@app.get("/login", response_class=HTMLResponse)
async def serve_login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# Подключаем API-роуты
app.include_router(auth_router)
